import { Component } from '@angular/core';

@Component({
  selector: 'app-contacts-page',
  imports: [],
  templateUrl: './contacts-page.component.html',
  styleUrl: './contacts-page.component.css'
})
export class ContactsPageComponent {

}
