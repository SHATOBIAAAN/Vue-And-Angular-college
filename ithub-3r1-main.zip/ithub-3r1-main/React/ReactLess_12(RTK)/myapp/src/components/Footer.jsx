



function Footer(){
    return (
        <div className="content">
            <div style={{width: '100%'}}>
                <iframe width="100%" height="200" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=200&amp;hl=en&amp;q=IThub%20moscow+(IThub)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a href="https://www.gps.ie/">gps trackers</a>
                </iframe>
            </div>
        </div>
    )
}
export default Footer