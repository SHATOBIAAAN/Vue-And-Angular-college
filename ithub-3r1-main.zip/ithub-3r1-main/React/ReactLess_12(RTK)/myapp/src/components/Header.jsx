




function Header(){
    return (
        <div className="header">
            <div className="header_wrapper content">
                <div className="logo"></div>
                <ul>
                    <li>Home</li>
                    <li>About</li>
                    <li>Contacts</li>
                </ul>
            </div>
        </div>
    )
}
export default Header