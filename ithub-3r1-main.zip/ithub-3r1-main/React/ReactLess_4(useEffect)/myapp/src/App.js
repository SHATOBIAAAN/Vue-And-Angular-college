import Example from "./components/Example";
import Users from "./components/Users";



function App() {
  return (
    <div >
      {/* <Example/> */}
      <Users/>
    </div>
  );
}

export default App;
