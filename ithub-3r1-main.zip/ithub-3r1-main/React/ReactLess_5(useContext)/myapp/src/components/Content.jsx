import Block from "./Block";


function Content() {
    return (
      <div>
        <Block/>
      </div>
    );
  }
  
export default Content;
  