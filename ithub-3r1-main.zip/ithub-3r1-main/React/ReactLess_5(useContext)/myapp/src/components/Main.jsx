import Content from "./Content";


function Main() {
    return (
      <div>
        <Content/>
      </div>
    );
  }
  

export default Main;
  