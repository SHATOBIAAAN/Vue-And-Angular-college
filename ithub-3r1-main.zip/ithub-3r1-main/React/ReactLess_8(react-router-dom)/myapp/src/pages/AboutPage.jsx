


function AboutPage(){
    return (
        <div className="content">
            <h1>About content</h1>
        </div>
    )
}

export default AboutPage