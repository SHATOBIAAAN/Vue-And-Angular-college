


function HomePage(){
    return (
        <div className="content">
            <h1>Home content</h1>
        </div>
    )
}

export default HomePage