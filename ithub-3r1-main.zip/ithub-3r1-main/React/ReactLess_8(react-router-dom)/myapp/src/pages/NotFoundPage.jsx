
import NotFoumdImg from '../assets/NotFoumdImg.png'


function NotFoundPage(){
    return (
        <div className="content">
            <img width={400} src={NotFoumdImg}/>
        </div>
    )
}

export default NotFoundPage