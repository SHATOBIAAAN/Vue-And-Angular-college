import Basket from "../../components/Basket";

const BasketPage = () => {
    return (
        <>
            <Basket />
        </>
    );
}

export default BasketPage;