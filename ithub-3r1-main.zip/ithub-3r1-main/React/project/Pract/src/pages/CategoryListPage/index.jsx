import CategoryList from "../../components/CategoryList";

const CategoryListPage = () => {
    return (
        <>
            <CategoryList />
        </>
    );
}

export default CategoryListPage;