import NotFound from "../../components/NotFound";

const NotFoundPagePage = () => {
    return (
        <>
            <NotFound />
        </>
    );
}

export default NotFoundPagePage;