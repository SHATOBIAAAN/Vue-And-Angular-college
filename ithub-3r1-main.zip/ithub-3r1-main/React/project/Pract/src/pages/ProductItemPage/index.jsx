import ProductInfo from "../../components/ProductInfo";

const ProductItemPage = () => {
    return (
        <>
            <ProductInfo />
        </>
    );
}

export default ProductItemPage;