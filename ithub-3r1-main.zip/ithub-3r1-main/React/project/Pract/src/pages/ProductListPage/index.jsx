import ProductList from "../../components/ProductList";

const ProductListPage = () => {
    return (
        <>
            <ProductList />
        </>
    );
}

export default ProductListPage;