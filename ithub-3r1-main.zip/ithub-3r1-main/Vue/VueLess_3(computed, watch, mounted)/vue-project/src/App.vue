<template>
  <Example/>
  <UserList/>
</template>

<script>
import Example from './components/Example.vue';
import UserList from './components/UserList.vue';

export default {
  components: {
    Example,
    UserList
  }
}
</script>


<style scoped>
</style>