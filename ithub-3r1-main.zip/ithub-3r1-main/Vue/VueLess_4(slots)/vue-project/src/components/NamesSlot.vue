<template>
    <slot name="slot_1"></slot>
    <p>Names Slot component</p>
    <slot name="slot_2"></slot>
</template>

<script>
export default {

}
</script>

