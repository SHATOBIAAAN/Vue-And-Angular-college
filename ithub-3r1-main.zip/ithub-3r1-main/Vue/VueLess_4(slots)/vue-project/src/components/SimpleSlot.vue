<template>
    <p>Simple Slot component</p>
    <!-- Вставка слота -->
    <slot></slot>
</template>

<script>
export default {

}
</script>

