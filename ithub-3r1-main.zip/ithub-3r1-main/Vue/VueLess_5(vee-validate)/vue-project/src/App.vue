<template>
  <NameForm></NameForm>
</template>

<script>
import NameForm from './components/NameForm.vue';

export default {
  components: {
    NameForm
  }
}
</script>
