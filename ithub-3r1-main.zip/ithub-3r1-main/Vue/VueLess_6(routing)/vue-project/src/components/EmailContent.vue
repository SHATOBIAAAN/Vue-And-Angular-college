<template>
    <div>
        <p>{{ email }}</p>
    </div>
</template>

<script>
    export default {
        props: {
            email: String
        }
    }
</script>