<template>
    <div>
        <p>{{ phone }}</p>
    </div>
</template>

<script>
    export default {
        props: {
            phone: String
        }
    }
</script>