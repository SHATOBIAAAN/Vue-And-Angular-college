<template>
    <section class="main">
        <h1>Home page!</h1>
    </section>
</template>

<script>
export default{

}
</script>

<style>
    .main{
        margin: 100px 0px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>