<template>
  <Counter></Counter>
  <UserList></UserList>
</template>


<script setup>
import Counter from './components/Counter.vue';
import UserList from './components/UserList.vue';

</script>